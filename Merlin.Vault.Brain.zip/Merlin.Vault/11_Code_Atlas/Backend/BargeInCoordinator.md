---
type: code-atlas
status: current
project: Merlin
tags:
  - merlin
  - code-atlas
  - voice
---

# BargeInCoordinator

## File

`Merlin.Backend/Services/BargeIn/BargeInCoordinator.cs`

## Purpose

Coordinates microphone-triggered capture, STT, live utterance routing, interruption handling, and backend voice request emission.

## PR10.4c Responsibilities

| Area | Responsibility |
| --- | --- |
| Pending clarification consume seam | Checks `IPendingInterruptionClarificationService.TryConsumeResponse` before awake gate/live gate/normal backend voice routing. |
| Awaiting response transition | Emits `interruptionState=handling` with reason `pending_interruption_clarification_response_captured` when a pending clarification answer is consumed. |
| Routing boundary | Raises `LiveUserUtteranceRouted` with `PendingInterruptionClarificationResponse` instead of generic command routing for bound clarification answers. |

## Important Methods

| Method | Role |
| --- | --- |
| `HandleTriggeredSpeechAsync` | Captures speech, runs STT, consumes pending clarification responses before normal routing, and routes utterances. |
| `TryConsumePendingInterruptionClarificationAsync` | PR10.4b/10.4c consume hook for pending clarification answers. |
| `EmitAssistantUiStateImmediateAsync` | Emits immediate assistant UI/backend state events through `AssistantUiStateBroadcaster`. |

## Non-Goals

- Does not own pending clarification storage.
- Does not own pending timeout recovery.
- Does not implement full AskClarification recomposition.
- Does not implement the PR10.4d stale `handling` watchdog.

## Tests

| Test File | Coverage |
| --- | --- |
| `Merlin.Backend.Tests/BargeInTests.cs` | Pending clarification response bypasses normal backend request routing and transitions from awaiting to handling. |

## Known Gaps

- Existing BargeIn idle-capture tests still fail independently of PR10.4c.
- General stale `InterruptionState=handling` watchdog remains PR10.4d.

## Related Notes

- [[PendingInterruptionClarificationService]]
- [[LiveInterruptionIntegrationService]]
- [[AskClarification Live Dead-End Recovery Plan]]
