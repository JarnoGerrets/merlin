---
type: changelog
status: current
year: 2026
---

# 2026 Change Log

## 2026-07-07

- Implemented AskClarification PR10.4c awaiting clarification state and timeout recovery:
  - added canonical `awaiting_interruption_clarification` interruption state
  - pending AskClarification creation now emits awaiting state
  - pending clarification responses transition back to `handling`
  - pending expiry/cancellation clears awaiting state back to `none`
  - active timeout recovery uses `PendingInterruptionClarificationTimeoutMs`
  - full PR10.4 remains blocked by stale handling watchdog and recomposition ownership
  - related run: [[RUN-2026-07-07-008 AskClarification PR10.4c Awaiting State Timeout]]

- Implemented the Derived Work Planning Layer for Merlin.Vault:
  - created [[PE-0260 Derived Work Planning Rules]]
  - added stable `DW`, `PLAN`, and `PROMPT` ID rules for discovered follow-up work
  - added derived implementation plan/prompt templates and [[Derived Work Index]]
  - updated `AGENT.md`, writeback rules, prompt conventions, bundles, indexes, dashboard, and run-report template
  - runtime code changed: no
  - related run: [[RUN-2026-07-07-007 Derived Work Planning Layer]]

- Implemented AskClarification PR10.4b pending unclear-interruption clarification owner:
  - added pending owner model/interface/service with expiry, consume, and cancel APIs
  - added opt-in live AskClarification owner creation
  - pending clarification responses now bypass normal backend voice request routing
  - full PR10.4 remains blocked by awaiting state, timeout recovery, watchdog, and recomposition ownership
  - related run: [[RUN-2026-07-07-006 AskClarification PR10.4b Pending Owner]]

- Completed AskClarification PR10.4 prerequisite investigation:
  - full PR10.4 implementation remains No-Go
  - required sequence is PR10.4b pending owner, PR10.4c awaiting state/timeout, PR10.4d watchdog, PR10.4e full recomposition ownership
  - runtime code changed: no
  - related run: [[RUN-2026-07-07-005 AskClarification PR10.4 Prerequisite Investigation]]

- Added strict Go / No-Go rules to the Merlin Vault agent operating system:
  - created [[PE-0008 Go No-Go Rules]]
  - added PE-0008 to implementation, bugfix, refactor, and investigation bundles
  - updated prompt conventions, templates, preflight checklist, writeback rules, dashboard, and AskClarification lesson
  - runtime code changed: no
  - related run: [[RUN-2026-07-07-004 Go No-Go Rules]]

- Finalized AskClarification PR7 dead-end safe fallback verification:
  - plan status corrected to partial / not ready for full-agent execution
  - 9 previously failing backend tests rerun individually and classified
  - full pending unclear-interruption clarification owner remains future/follow-up
  - related run: [[RUN-2026-07-07-003 AskClarification Dead-End Safe Fallback]]

- Implemented AskClarification live dead-end recovery minimal fix:
  - removed the stale live PR7 deferred AskClarification path
  - added terminal fallback resume/cleanup for ownerless live interruption strategies
  - added `in the pool` regression coverage
  - related run: [[RUN-2026-07-07-002 AskClarification Live Dead-End Recovery]]

- Enriched Merlin.Vault operating system with prompt bundles, run naming rules, bug lifecycle, current work dashboard, maintenance checklist, implementation plan lifecycle, and curated plan naming cleanup.

- Added Agent Operating System structure to Merlin.Vault:
  - prompt extensions
  - agent run reports
  - progress reports
  - changelog
  - writeback rules
- Related run: [[RUN-2026-07-07-001 Vault Agent Operating System]]
