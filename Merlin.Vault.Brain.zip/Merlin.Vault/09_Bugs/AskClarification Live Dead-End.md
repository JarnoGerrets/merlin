---
type: bug
status: fixed-mitigated
area: voice
first_seen: 2026-07-07
last_updated: 2026-07-07
---

# AskClarification Live Dead-End

## Summary

Live interruption utterances classified as `AskClarification` could enter a stale PR7 deferred branch with no executable live owner. The observed failure mode was a short utterance such as `in the pool` suppressing playback resume and leaving Merlin in an interruption handling state.

## User-Visible Impact

Merlin appeared to stop listening or stop responding after a live interruption. Internally, STT could still run, but the live interruption path had not resolved to resume, cancel, clarify, or route.

## Root Cause

`LiveInterruptionIntegrationService` still had a branch:

```text
Ask-user-to-clarify is not executed live in PR7.
```

That branch returned control to legacy semantic routing even though live playback resume had already been suppressed. Without a pending clarification owner, the result could become a terminal dead end.

## Fix Applied

Minimal safe terminal-outcome fix:

- Remove the stale PR7 defer branch for live `AskUserToClarifyInterruption`.
- Treat short unclear fragments as handled fallback outcomes.
- Resume provisional holds when available.
- Suppress legacy semantic routing for handled fallback outcomes.
- Add regression coverage for `in the pool`.

## Current Status

Fixed-mitigated.

The observed stale PR7 AskClarification short-fragment wedge is fixed. The broader unclear-interruption pending clarification system remains follow-up work.

## PR10.4 Investigation Status

Full PR10.4 remains blocked by missing prerequisites documented in [[AskClarification PR10.4 Prerequisite Investigation]].

PR10.4b has added the durable pending unclear-interruption clarification owner.

PR10.4c has added explicit `awaiting_interruption_clarification` state and timeout recovery. Do not implement the full AskClarification pending clarification/recomposition system until the stale handling watchdog and full recomposition ownership are in place.

## Remaining Risk

This is not the full PR10.4 clarification system. Merlin still lacks the stale handling watchdog and full PR10 clarification/recomposition ownership for all clarification branches.

## Regression Test

`ConversationalInterruptionLiveIntegrationTests.TryHandleYieldedInterruptionAsync_AskClarificationShortFragmentInThePool_ResumesHoldAndSuppressesSemanticRouting`

## Related Notes

- [[AskClarification Live Dead-End Recovery Plan]]
- [[LiveInterruptionIntegrationService]]
- [[Voice Interruption System]]
