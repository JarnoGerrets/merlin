---
type: agent-run-index
status: current
---

# Agent Run Index

## Purpose

This folder records what agents actually did during implementation, investigation, documentation, and cleanup tasks.

## Latest Runs

| Date | Run | Type | Related Feature | Result | Notes |
| --- | --- | --- | --- | --- | --- |
| 2026-07-07 | [[RUN-2026-07-07-001 Vault Agent Operating System]] | documentation | Vault / Agent Operating System | completed | Added prompt extensions, writeback rules, progress reports, changelog, and run ledger structure. |

## Rules

Every meaningful implementation task should create an agent run report.

## Naming Rules

Use [[Agent Run Naming Rules]]. Run reports use `RUN-YYYY-MM-DD-NNN Short Task Title.md` and include `run_id` in frontmatter.
